const fs = require('fs');
const path = require('path');
const AdmZip = require(path.join(__dirname, 'node_modules', 'adm-zip'));

// 1. Create project-compass-test.zip
const zip1 = new AdmZip();
zip1.addLocalFolder('.', 'project-compass', (p) => !p.includes('node_modules') && !p.includes('.git') && !p.includes('.next') && !p.includes('scratch'));
zip1.writeZip('project-compass-test.zip');
console.log('✓ Created project-compass-test.zip');

// 2. Create flask-test-project.zip
const zip2 = new AdmZip();
zip2.addFile('flask-app/app.py', Buffer.from("from flask import Flask\napp = Flask(__name__)\n\n@app.route('/api/hello')\ndef hello():\n    return {'status': 'ok'}\n\nif __name__ == '__main__':\n    app.run()\n"));
zip2.addFile('flask-app/requirements.txt', Buffer.from("flask==2.3.2\npsycopg2==2.9.6\nsqlalchemy==2.0.15\n"));
zip2.addFile('flask-app/models/user.py', Buffer.from("class User:\n    def __init__(self, username):\n        self.username = username\n"));
zip2.writeZip('flask-test-project.zip');
console.log('✓ Created flask-test-project.zip');
